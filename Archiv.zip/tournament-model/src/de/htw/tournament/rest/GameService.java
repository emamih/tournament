package de.htw.tournament.rest;

import javax.ws.rs.Path;

//@Path("games")
public class GameService {

}
