package de.htw.tournament.model;
// default package
// Generated 09.02.2015 16:09:37 by Hibernate Tools 4.3.1


//@Entity
//@Table(name = "divisionscoresheetentry", catalog = "tournament")
public class Divisionscoresheetentry implements java.io.Serializable {

//	/**
//	 * 
//	 */
	private static final long serialVersionUID = 1L;
//	
//	@EmbeddedId
//	@AttributeOverrides({
//			@AttributeOverride(name = "competitorReference", column = @Column(name = "competitorReference", nullable = false)),
//			@AttributeOverride(name = "rootReference", column = @Column(name = "rootReference")),
//			@AttributeOverride(name = "score", column = @Column(name = "score", precision = 27, scale = 0)),
//			@AttributeOverride(name = "opponentScore", column = @Column(name = "opponentScore", precision = 27, scale = 0)),
//			@AttributeOverride(name = "points", column = @Column(name = "points", precision = 22, scale = 0)) })
//	private DivisionscoresheetentryId id;
//
//	public Divisionscoresheetentry() {
//	}
//
//	public Divisionscoresheetentry(DivisionscoresheetentryId id) {
//		this.id = id;
//	}
//
//	
//	public DivisionscoresheetentryId getId() {
//		return this.id;
//	}
//
//	public void setId(DivisionscoresheetentryId id) {
//		this.id = id;
//	}

}
